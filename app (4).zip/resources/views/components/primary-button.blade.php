<button class="btn btn-primary w-100">
    {{ $slot }}
</button>

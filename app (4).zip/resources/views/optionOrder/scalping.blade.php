<x-app-layout>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <h5 class="card-title">Option Scalper 5 Points (SL 5)</h5>
                            <a class="btn btn-lg btn-success px-5" href="{{ url('nifty-bank-scalpe/CE/1') }}">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="{{ url('nifty-bank-scalpe/PE/1') }}">PUT</a>
                        <h5 class="card-title">Option Scalper 8 Points (SL 8)</h5>
                            <a class="btn btn-lg btn-success px-5" href="{{ url('nifty-bank-scalpe/CE/2') }}">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="{{ url('nifty-bank-scalpe/PE/2') }}">PUT</a>
                        <h5 class="card-title">Option Scalper 10 Points (SL 10)</h5>
                            <a class="btn btn-lg btn-success px-5" href="{{ url('nifty-bank-scalpe/CE/3') }}">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="{{ url('nifty-bank-scalpe/PE/3') }}">PUT</a>
                        <h5 class="card-title">Option Scalper 12 Points (SL 12)</h5>
                            <a class="btn btn-lg btn-success px-5" href="{{ url('nifty-bank-scalpe/CE/3') }}">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="{{ url('nifty-bank-scalpe/PE/3') }}">PUT</a>
                        
                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

</x-app-layout>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">
                    
                    <?php 
                    $dataArray = [];
                    foreach($logs as $title => $row)
                    {
                        $data = [];
                        foreach($row as $log)
                        {
                           if(!array_key_exists(date('d-m-Y',strtotime($log->created_at)),$data)) $data[date('d-m-Y',strtotime($log->created_at))] = 0;
                            if ($log->type == 'buy') {
                                  $data[date('d-m-Y',strtotime($log->created_at))]-= $log->price;    
                            } else {
                                 $data[date('d-m-Y',strtotime($log->created_at))]+= $log->price;    
                            }
                           
                        }
                        $profit = 0;
                        $weeksProfit = array(
                            'Mon' => 0,
                            'Tue' => 0,
                            'Wed' => 0,
                            'Thu' => 0,
                            'Fri' => 0,
                            );
                        $weeksLoss = array(
                            'Mon' => 0,
                            'Tue' => 0,
                            'Wed' => 0,
                            'Thu' => 0,
                            'Fri' => 0,
                            );    
                        foreach($data as $key => $value)
                        {
                            if($value > 0) {
                                $profit++;
                                $weeksProfit[date('D', strtotime($key))]++;
                            } else{
                               $weeksLoss[date('D', strtotime($key))]++;
                            }
                            
                        }
                        $summary = array(
                            'total' => sizeof($data),
                            'profit' => $profit,
                            'weekProfit'=> $weeksProfit,
                            'weekLoss' => $weeksLoss,
                            'data' => $data,
                            'title'=> $title
                            );
                        $dataArray[$title] = $summary;
                    }
                    
                    ?>

                    <div class="card-body">
                        <h5 class="card-title">Log Summary</h5>
                        <?php $__currentLoopData = $dataArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12">
                                <table class="table table-striped">
                                    <tr>
                                        <td width="200"><strong><?php echo e($row['title']); ?></strong></td>
                                        <td>
                                            <table>
                                                <tr>
                                                    <td>Total Trades: <?php echo e($row['total']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Total Profit: <?php echo e($row['profit']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Total Loss: <?php echo e($row['total'] - $row['profit']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Profit Percentage: <?php echo e(number_format(($row['profit']/$row['total']) * 100, 2)); ?>%</td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td>
                                            <table class="table table-bordered">
                                                <thead>
                                                    <th>Day</th>
                                                    <th>Profit</th>
                                                    <th>Loss</th>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $row['weekProfit']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $dayData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($day); ?></td>
                                                        <td><?php echo e($dayData); ?></td>
                                                        <td><?php echo e($row['weekLoss'][$day]); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/logs/logReports.blade.php ENDPATH**/ ?>
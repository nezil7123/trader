<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">
                    <?php 
                        usort($data, function($a, $b) {return $a->v->chp < $b->v->chp;});
                    ?>
                    <div class="card-body">
                        <h5 class="card-title">Orders</h5>

                        <table class="table table-borderless table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Symbol</th>
                                    <th scope="col">Change</th>
                                    <th scope="col">LTP</th>
                                    <th scope="col">Open</th>
                                    <th scope="col">High</th>
                                    <th scope="col">Low</th>
                                    <th scope="col">Spread</th>
                                    <th scope="col">Volume</th>
                                    <th scope="col">Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i=1;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?=$i++ ?>
                                        </td>
                                        <td>
                                            <?php echo e($row->v->short_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($row->v->chp); ?>%
                                        </td>
                                        <td>
                                            <?php echo e($row->v->lp); ?>

                                        </td>
                                         <td>
                                            <?php echo e($row->v->open_price); ?>

                                        </td>
                                        <td>
                                            <?php echo e($row->v->high_price); ?>

                                        </td>
                                         <td>
                                            <?php echo e($row->v->low_price); ?>

                                        </td>
                                         <td>
                                            <?php echo e($row->v->spread); ?>

                                        </td>
                                        <td>
                                            <?php echo e($row->v->volume); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('stock-buy/'.urlencode($row->v->symbol).'/'.$row->v->ask)); ?>" class="btn btn-success">Buy</a>
                                            <a href="<?php echo e(url('stock-sell/'.urlencode($row->v->symbol).'/'.$row->v->bid)); ?>" class="btn btn-danger">Sell</a>
                                        </td>
                                    </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </tbody>
                        </table>

                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>


    $(document).ready(function(){
         $.get("https://www.nseindia.com/api/live-analysis-variations?index=gainers", function(data, status){
            console.log(data);
          });
    });
</script>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/data/top_gainers_nse.blade.php ENDPATH**/ ?>
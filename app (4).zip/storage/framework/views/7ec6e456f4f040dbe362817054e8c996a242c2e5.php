<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <h5 class="card-title">Option Scalper 5 Points (SL 5)</h5>
                            <a class="btn btn-lg btn-success px-5" href="<?php echo e(url('nifty-bank-scalpe/CE/1')); ?>">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="<?php echo e(url('nifty-bank-scalpe/PE/1')); ?>">PUT</a>
                        <h5 class="card-title">Option Scalper 8 Points (SL 8)</h5>
                            <a class="btn btn-lg btn-success px-5" href="<?php echo e(url('nifty-bank-scalpe/CE/2')); ?>">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="<?php echo e(url('nifty-bank-scalpe/PE/2')); ?>">PUT</a>
                        <h5 class="card-title">Option Scalper 10 Points (SL 10)</h5>
                            <a class="btn btn-lg btn-success px-5" href="<?php echo e(url('nifty-bank-scalpe/CE/3')); ?>">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="<?php echo e(url('nifty-bank-scalpe/PE/3')); ?>">PUT</a>
                        <h5 class="card-title">Option Scalper 12 Points (SL 12)</h5>
                            <a class="btn btn-lg btn-success px-5" href="<?php echo e(url('nifty-bank-scalpe/CE/3')); ?>">CALL</a>
                            <a class="btn btn-lg btn-danger px-5" href="<?php echo e(url('nifty-bank-scalpe/PE/3')); ?>">PUT</a>
                        
                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/optionOrder/scalping.blade.php ENDPATH**/ ?>
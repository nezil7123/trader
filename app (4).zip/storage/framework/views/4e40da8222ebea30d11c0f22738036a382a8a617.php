<button class="btn btn-primary w-100">
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\trading\resources\views/components/primary-button.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">
                    <?php 
                    $types = array(
                        '1' => 'Limit Order',
                        '2' => 'Market Order',
                        '3' => 'Stop Order / SL-M',
                        '4' => 'Stop Limit Order/ SL-L'
                    );
                    $productTypes = array(
                     
                    );
                    $status = array(
                        '1' => 'Active',
                        '0' => 'Inactive',
                    );
                    $sl = 1;
                    ?>
                    <div class="card-body">
                        <h5 class="card-title">Stocks</h5>

                        <table class="table table-borderless datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Symbol</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a href="#">#<?php echo e($sl++); ?></a></th>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->symbol); ?></td>
                                    <td><a class="badge bg-<?php echo e($item->status ? 'success' : 'danger'); ?> change-status" data-id=<?php echo e($item->id); ?>><?php echo e($status[$item->status]); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $(document).on('click', '.change-status' ,function(){
   var id = $(this).attr('data-id');
   var item = this;
   $.get("<?php echo e(url('updateStatus')); ?>/"+id, function(data, status){
    if(data == '1'){
        $(item).removeClass('bg-danger');
        $(item).addClass('bg-success');
        $(item).html("Active");
    }else{
        $(item).addClass('bg-danger');
        $(item).removeClass('bg-success');
        $(item).html("InActive");
    }
  });
  });
});
</script>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/data/listStocks.blade.php ENDPATH**/ ?>
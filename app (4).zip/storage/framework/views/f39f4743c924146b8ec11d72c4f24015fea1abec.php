<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <h5 class="card-title">Automations</h5>
                        <div class="btn-group" role="group" aria-label="Basic outlined example">
                            <a class="btn btn-outline-primary" href="<?= url('/logs/ALL') ?>">ALL</a>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-outline-primary"
                                    href="<?= url('/logs/' . urlencode($type->title)) ?>"><?php echo e($type->title); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Message</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <?php
                            $profit = 0;
                            function random_color_part()
                            {
                                return str_pad(dechex(mt_rand(180, 255)), 2, '0', STR_PAD_LEFT);
                            }
                            
                            function random_color()
                            {
                                return random_color_part() . random_color_part() . random_color_part();
                            }
                            $color = random_color();
                            $date = '';
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if ($log->type == 'buy') {
                                        $profit -= $log->price * 1000;
                                    } else {
                                        $profit += $log->price * 1000;
                                    }
                                    
                                    if (date('d-m-Y', strtotime($log->created_at)) != $date) {
                                        $color = random_color();
                                    }
                                    $date = date('d-m-Y', strtotime($log->created_at));
                                    ?>
                                    <tr style="background: #<?= $color ?>">
                                        <th scope="row"><?php echo e($log->id); ?></th>
                                        <td><?php echo e($log->title); ?></td>
                                        <td><?php echo e(date('d-m-Y H:i:s', strtotime($log->created_at))); ?></td>
                                        <td><?php echo e($log->message); ?></td>
                                        <td><?php echo e($log->type); ?></td>
                                        <td><?php echo e(number_format($log->price, 2)); ?></td>
                                        <td><?php echo e(number_format($log->price * 1000, 2)); ?></td>
                                        <td><?php echo e($profit); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"></th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo e($profit); ?></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\trading\resources\views/logs/index.blade.php ENDPATH**/ ?>
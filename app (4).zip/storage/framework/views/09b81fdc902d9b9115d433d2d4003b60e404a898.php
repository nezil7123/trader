<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">
                    <?php 
                    $types = array(
                        '1' => 'Buy',
                        '-1' => 'Sell'
                    );
                    $productTypes = array(
                     
                    );
                    $status = array(
                        1 => "Profit",
                        0 => "Loss"
                    );

                    ?>
                  
                    
                    <div class="card-body">
                        <h5 class="card-title">Orders</h5>

                        <table class="table table-borderless datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Symbol</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Time</th>
                                    <th scope="col">Day</th>
                                    <th scope="col">Strategy</th>
                                    <th scope="col">Order Type</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a href="#">#<?php echo e($item->id); ?></a></th>
                                    <td><?php echo e($item->symbol); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                    <td><?php echo e(date('h:i:s', strtotime($item->created_at))); ?></td>
                                    <td><?php echo e($item->day); ?></td>
                                    <td><?php echo e($item->code); ?></td>
                                    <td><?php echo e($types[$item->side]); ?></td>
                                   
                                    <td><span class="badge bg-<?php echo e($item->profit ? 'success' : 'danger'); ?>"><?php echo e($status[$item->profit]); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card recent-sales overflow-auto">
                  <div class="card-body">
                        <table class="table table-borderless datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Strategy</th>
                                    <th scope="col">Total Trade</th>
                                    <th scope="col">Profit</th>
                                    <th scope="col">Loss</th>
                                    <th scope="col">%</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $codeLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><a href="#">#<?php echo e($item->id); ?></a></th>
                                <td><?php echo e($item->code); ?></td>
                                <td><?php echo e($item->count); ?></td>
                                <td><?php echo e($item->profit); ?></td>
                                <td><?php echo e($item->count - $item->profit); ?></td>
                                <td><?php echo e(number_format(($item->profit/$item->count) * 100,2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>
                   </div>
            </div>
            <div class="col-md-6">
                 <div class="card recent-sales overflow-auto">
                  <div class="card-body">
                        <table class="table table-borderless datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Symbol</th>
                                    <th scope="col">Total Trade</th>
                                    <th scope="col">Profit</th>
                                    <th scope="col">Loss</th>
                                    <th scope="col">%</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $symbolLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><a href="#">#<?php echo e($item->id); ?></a></th>
                                <td><?php echo e($item->symbol); ?></td>
                                <td><?php echo e($item->count); ?></td>
                                <td><?php echo e($item->profit); ?></td>
                                <td><?php echo e($item->count - $item->profit); ?></td>
                                <td><?php echo e(number_format(($item->profit/$item->count) * 100,2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $weekData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $weekItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card recent-sales overflow-auto">
                    <div class="card-body">
                        <h4 class="py-2"><?php echo e($week); ?></h4>
                        <table class="table table-borderless datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Code</th>
                                    <th scope="col">Total Trade</th>
                                    <th scope="col">Profit</th>
                                    <th scope="col">Loss</th>
                                    <th scope="col">%</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $weekItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><a href="#">#<?php echo e($item->id); ?></a></th>
                                <td><?php echo e($item->code); ?></td>
                                <td><?php echo e($item->count); ?></td>
                                <td><?php echo e($item->profit); ?></td>
                                <td><?php echo e($item->count - $item->profit); ?></td>
                                <td><?php echo e(number_format(($item->profit/$item->count) * 100,2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/order/index.blade.php ENDPATH**/ ?>
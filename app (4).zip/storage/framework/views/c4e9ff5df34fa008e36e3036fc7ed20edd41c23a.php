<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">
                    <?php 
                    $types = array(
                        '1' => 'Limit Order',
                        '2' => 'Market Order',
                        '3' => 'Stop Order / SL-M',
                        '4' => 'Stop Limit Order/ SL-L'
                    );
                    $productTypes = array(
                     
                    );
                    $status = array(
                        '1' => 'Active',
                        '0' => 'Inactive',
                    );
                    $sl = 1;
                    ?>
                    <div class="card-body">
                        <h5 class="card-title">Alert Logs</h5>

                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Symbol</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Product Type</th>
                                    <th scope="col">Take Profit</th>
                                    <th scope="col">Stop Loss</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a href="#">#<?php echo e($sl++); ?></a></th>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->symbol); ?></td>
                                    <td><?php echo e($types[$item->type]); ?></td>
                                    <td><?php echo e($item->product_type); ?></td>
                                    <td><?php echo e($item->take_profit); ?></td>
                                    <td><?php echo e($item->stop_loss); ?></td>
                                    <td><span class="badge bg-<?php echo e($item->status ? 'success' : 'danger'); ?>"><?php echo e($status[$item->status]); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/automated/index.blade.php ENDPATH**/ ?>
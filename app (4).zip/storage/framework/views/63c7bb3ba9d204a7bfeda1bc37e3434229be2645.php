<button class="btn btn-primary w-100">
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/components/primary-button.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section profile">
        <div class="row">
            <div class="col-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <h5 class="card-title">Option Logs</h5>
                         <div class="btn-group" role="group" aria-label="Basic outlined example">
                            <a class="btn btn-outline-primary" href="<?= url('/option-logs/TODAY') ?>">TODAY</a>
                            <a class="btn btn-outline-primary" href="<?= url('/option-logs/MONTH') ?>">MONTH</a>
                            <a class="btn btn-outline-primary" href="<?= url('/option-logs/ALL') ?>">ALL</a>
                        </div>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Symbol</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">LTP</th>
                                    <th scope="col">Entry</th>
                                    <th scope="col">Target</th>
                                    <th scope="col">Stoploss</th>
                                    <th scope="col">Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $profit = 0;
                                ?>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                    
                                    $date = date('d-m-Y', strtotime($log->created_at));
                                    ?>
                                    <tr>
                                        <th scope="row"><?php echo e($log->id); ?></th>
                                        <td><?php echo e($log->symbol); ?> &nbsp;<span class="badge bg-info"><?php echo e(substr($log->symbol,18,7)); ?></span></td>
                                        <td><?php echo e(date('d-m-Y H:i:s', strtotime($log->created_at))); ?></td>
                                        <td><?php echo e($log->ltp); ?></td>
                                        <td><?php echo e($log->price); ?></td>
                                        <td><?php echo e(number_format($log->price + $log->take_profit, 2)); ?></td>
                                        <td><?php echo e(number_format($log->price - $log->stop_loss, 2)); ?></td>
                                        <td>
                                            <?php 
                                            if($log->profit == 1)
                                            {
                                                 echo "Profit";
                                                 $profit += ($log->price) * (18/100) * 25;
                                            }
                                            else if($log->profit == -1)
                                            {
                                                 echo "Loss";
                                                 $profit -= ($log->price) * (18/100) * 25;
                                            }
                                            else
                                            {
                                                echo "Pending";
                                            }
                                                
                                            
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"></th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo e($profit); ?></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div><!-- End Recent Sales -->
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/nikahos1/trade.a2hosted.com/trading_app/resources/views/optionOrder/index.blade.php ENDPATH**/ ?>